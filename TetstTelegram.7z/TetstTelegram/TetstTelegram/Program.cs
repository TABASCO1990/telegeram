﻿using System;
using System.Threading;
using Telegram.Bot;
using Telegram.Bot.Args;

namespace TetstTelegram
{
    class Program
    {
        private static string token { get; set; } = "5231353402:AAFc8DfVqWhQq97hsxZB8oQQRWFdS4MJAvA";
        private static TelegramBotClient client;
        static void Main(string[] args)
        {
            client = new TelegramBotClient(token);
            client.StartReceiving();
            client.SendTextMessageAsync("-726928036", "Привет");
            Thread.Sleep(10000);
            client.StopReceiving();

        }

       /* private static void OnMessageHandler(object sender, MessageEventArgs e)
        {
            client.SendTextMessageAsync("-726928036", "Привет");
        }*/
    }
}
